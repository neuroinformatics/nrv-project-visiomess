[Title]
Interactive illustration for mechanism of two types of bimodal direction tuning.

[Author]
Okamoto H

[E-mail]
h-okamoto@jp.fujitsu.com

[Contents]
This package contains the following files:

    readme.txt: this file
    license.txt: license document

    top.htm
    component0.png - component4.png: pictures for component cells
    pattern0.png - pattern4.png: pictures for pattern cells

[Usage]

0) Open the file `top.htm' with a web browser supporting JavaScript 1.1 or later.

1) Click the linked text to change illustrations.

[Description]

This content illustrates the mechanism of two types of bimodal direction tuning based on the model.

(Last modified 11/27/2003)

