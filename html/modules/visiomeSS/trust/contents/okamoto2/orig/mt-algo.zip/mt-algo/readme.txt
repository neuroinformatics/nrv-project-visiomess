[Title]
Interactive illustration of local velocity detection algorithm.

[Author]
Okamoto H

[E-mail]
h-okamoto@jp.fujitsu.com

[Contents]
This package contains the following files:

    readme.txt: this file
    licence.txt: licence document

    top.htm: top page for web browser
    original-hough.htm
    hough.htm
    velocity-detection.htm

    original-definition.png
    hough-definition.png
    hough-example.png

    OriginalHough.class
    Hough.class
    MTmodel.class
    mtlib/MtGraphLib.class

[Usage]

0) Open the file `top.htm' with a web browser supporting Java Applets(*).

1) Select a page.

2) Please follow the instructions on each page.

*) This content was developed by JAVA 2 SDK 1.4.1_02 on Linux.
   Java 2 v1.3.1_02 or later is needed for IE6 with Windows.

J2SE download page:
http://java.sun.com/j2se/1.4/index.html (version 1.4.x)

(Last modified 11/26/2003)

